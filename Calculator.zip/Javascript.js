var display = document.getElementById("Display");
function Buttons (F) {
	display.innerHTML = display.innerHTML + F;
}
console.log("testing")
function Operator1 (F) {
	display.innerHTML = display.innerHTML + F;
}
function Operator2 (F) {
	display.innerHTML = display.innerHTML + F;
}
function Operator3 (F) {
	display.innerHTML = display.innerHTML + F;
}
function Operator4 (F) {
	display.innerHTML = display.innerHTML + F;
}
function Operator5 (F) {
	display.innerHTML = display.innerHTML + F;
}